# LearningHadoop2
Data files for the Learning Hadoop 2 video training by Packt Publishing
